﻿using System;

namespace RadioApp
{
    public class Radio
    {

    }
    // implement a class Radio that corresponds to the Class diagram 
    //   and specification in the Radio_Mini_Project document
}
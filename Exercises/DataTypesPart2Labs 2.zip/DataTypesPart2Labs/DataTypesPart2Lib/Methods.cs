﻿using System;

namespace DataTypesPt2Lib
{
    public enum Suit
    {
        HEARTS, CLUBS, DIAMONDS, SPADES
    }
    public class Methods
    {
        public static int AgeAt(DateTime birthDate, DateTime date)
        {
            return -1;
        }

        public static string FormatDate(DateTime date)
        {
            return string.Empty;
        }
        public static string GetMonthString(DateTime date)
        {
            return string.Empty;
        }

        public static string Fortune(Suit suit)
        {
            return string.Empty;
        }
    }
}
    
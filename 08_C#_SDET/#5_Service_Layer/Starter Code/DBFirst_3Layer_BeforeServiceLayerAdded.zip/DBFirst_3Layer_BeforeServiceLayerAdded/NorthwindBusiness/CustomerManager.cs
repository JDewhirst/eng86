﻿using System;
using System.Collections.Generic;
using System.Linq;
using NorthwindData;

namespace NorthwindBusiness
{
    public class CustomerManager
    {
        public Customer SelectedCustomer { get; set; }

        public void CreateCustomer(string customerId, string contactName = null, string city = null, string postalCode = null, string country = null, string companyName = "")
        {
            var newCust = new Customer() { CustomerId = customerId, ContactName = contactName, City = city, PostalCode = postalCode, Country = country, CompanyName = companyName };
            using (var db = new NorthwindContext())
            {
                db.Customers.Add(newCust);
                db.SaveChanges();
            }
        }

        public void UpdateCustomer(string customerId, string contactName, string city, string postcode, string country, string companyName)
        {
            using (var db = new NorthwindContext())
            {
                SelectedCustomer = db.Customers.Where(c => c.CustomerId == customerId).FirstOrDefault();
                SelectedCustomer.ContactName = contactName;
                SelectedCustomer.City = city;
                SelectedCustomer.PostalCode = postcode;
                SelectedCustomer.Country = country;
                SelectedCustomer.CompanyName = companyName;

                // write changes to database
                db.SaveChanges();
            }
        }


        public List<Customer> RetrieveAllCustomers()
        {
            using (var db = new NorthwindContext())
            {
                return db.Customers.ToList();
            }
        }

        public void SetSelectedCustomer(object selectedItem)
        {
            SelectedCustomer = (Customer)selectedItem;
        }

        public void DeleteCustomer(string customerid)
        {
            using (var db = new NorthwindContext())
            {
                var selectedCustomer =
            from c in db.Customers
            where c.CustomerId == customerid
            select c;

                db.Customers.RemoveRange(selectedCustomer);


                db.SaveChanges();
            }
        }

        public bool CheckCustomerExists(string customerid)
        {
            using (var db = new NorthwindContext())
            {
                var customer = db.Customers.Find(customerid);
                return customer != null ? true : false;
            }
            
          
        }
    }
}

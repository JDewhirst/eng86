﻿using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
namespace NorthwindData
{
    class Program
    {
        static void Main(string[] args)
        {
  
        }
    }
}
